from flask import Flask, render_template, Response
import cv2
import pytesseract
import time
from grovepi import *
import psycopg2
import threading
from grove_rgb_lcd import *
from gpiozero import Servo
from twilio.rest import Client
import pyrebase
from datetime import datetime
from time import *

app = Flask(__name__)

class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(0)

    def __del__(self):
        self.video.release()

    def get_frame(self):
        # extracting frames
        ret, frame = self.video.read()
        if ret:
            ret, jpeg = cv2.imencode('.jpg', frame)
            if ret:
                return jpeg.tobytes()

def gen(camera):
    while True:
        frame = camera.get_frame()
        if frame:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(gen(VideoCamera()), mimetype='multipart/x-mixed-replace; boundary=frame')

config = {
    "apiKey": "AIzaSyD6sOzc4YmwGIYo-Ee9j572yqAuCUwBPQo",
    "authDomain": "iot-assigment-bait2123",
    "databaseURL": "https://iot-assigment-bait2123-default-rtdb.asia-southeast1.firebasedatabase.app/",
    "storageBucket": "gs://iot-assigment-bait2123.appspot.com"
}

firebase = pyrebase.initialize_app(config)
auth = firebase.auth()
user = auth.sign_in_with_email_and_password("chanwahhong1537@gmail.com", "123123")
db = firebase.database()

pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract'

myGPIO=17
myCorrection=0.45
maxPW=(2.0+myCorrection)/1000
minPW=(1.0-myCorrection)/1000
myServo = Servo(myGPIO,min_pulse_width=minPW,max_pulse_width=maxPW)
myServo.value = None

ultrasonic_pin = 2
led_green_pin = 3
led_red_pin = 4
buzzer = 7
pinMode(buzzer, "OUTPUT")
pinMode(ultrasonic_pin, "INPUT")
pinMode(led_green_pin, "OUTPUT")
pinMode(led_red_pin, "OUTPUT")

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 50)  # Set webcam resolution
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 50)

def scroll_message(messageDB, speed=0.1):
    message_len = len(messageDB)
    lcd_width = 16  # Assuming 16 characters width for the LCD
    if message_len <= lcd_width:
        setText(messageDB)
        return

    for i in range(messageDB_len - lcd_width + 1):
        setText(messageDB[i:i+lcd_width])
        sleep(speed)

def empty_text():
    setText("")
    messageDB = ""
        
# Connect to the PostgreSQL database
def get_vehicle_id(plate_number):
    conn = psycopg2.connect(
        dbname="iot",
        user="kitmeng",
        password="123123",
        host="localhost"
    )
    
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM vehicles WHERE plate_num = %s", (plate_number,))
        row = cur.fetchone()
        return row is not None
    
    except psycopg2.Error as e:
        print("Error retrieving vehicle ID:", e)
        return False
    
    finally:
        if cur:
            cur.close()
        conn.close()

def car_detection():
    start_time = time.time()
    distance_below_time = None
    while True:
        try:
            digitalWrite(led_red_pin, 1)
            distance = ultrasonicRead(ultrasonic_pin)
            print("The car is", distance, "cm from the gate")
            if distance <= 10:
                digitalWrite(led_green_pin, 0)
                digitalWrite(led_red_pin, 1)
                setRGB(0, 255, 255)
                setText("Welcome to\nDallas Villa")
                time.sleep(2)
       
                # If the distance has been below the threshold for the first time, record the time
                if distance_below_time is None:
                    distance_below_time = time.time()
                    
                # Check if the distance has been below the threshold for around 5 seconds
                if time.time() - distance_below_time >= 300:
                    alarm()  # Trigger the alarm
                    # Exit the loop after triggering the alarm
                else:
                    digitalWrite(buzzer,0)
                    digitalWrite(led_red_pin, 1)
                    start_time = time.time()
                    # Read the camera frame
                    ret, img = cap.read()
                # Call perform_ocr with the camera frame
                    perform_ocr(img)
                    closegate()            
            else: 
                print("No car detected")
              
                digitalWrite(buzzer,0)
        except KeyboardInterrupt:
            digitalWrite(led_red_pin, 1)
            cap.release()  # Release the camera before exiting
            break
        except TypeError:
            print("Type Error Occurs")
        except IOError:
            print("IO Error Occurs")

def alarm():
    account_sid = 'ACa54071521f73b1de28262a1586c26c1c'
    auth_token = 'e513fbce38f2b169e08456df17e3c5d4'
    client = Client(account_sid, auth_token)

    message = client.messages.create(
      from_='+14692084115',
      body='There is vehicle block at the gate. Please aware of that!',
      to='+60166452099'
    )
    
    print("An alarm message has sent to the management!!!" )
    digitalWrite(buzzer,1)
    digitalWrite(led_red_pin, 1)
    time.sleep(1)
    digitalWrite(buzzer, 0)
    digitalWrite(led_red_pin, 0)
    time.sleep(0.1)
    
def perform_ocr(img):
    try:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        cv2.imshow('Beta', gray)
        k = cv2.waitKey(10)
        ret, img = cap.read() 
   
        # Perform OCR in a separate thread
        threading.Thread(target=perform_ocr, args=(img,)).start()
        # Apply adaptive thresholding
        thresholded = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        # Perform OCR on the thresholded image
        plate_number = pytesseract.image_to_string(thresholded, config='--psm 6')
        # Filter out non-alphanumeric characters
        plate_number = ''.join(filter(str.isalnum, plate_number))
    
        #plate_number='WA8047E'
        # Check if the plate number is valid
        if len(plate_number) <= 8 and len(plate_number) >= 3:
            print("\nPlate Number:", plate_number)
            # Select Carplate Number from database
            selectCarNum = get_vehicle_id(plate_number)
            if selectCarNum == True:
                print('found')
                digitalWrite(led_green_pin, 1)
                digitalWrite(led_red_pin, 0)
                messageDB = "Welcome," + plate_number +"\nResident " + datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                db.child("REC_001").push(messageDB, user['idToken'])
                setRGB(0, 255, 0)
                scroll_message(messageDB)
                time.sleep(2)
                empty_text()
                opengate()
                main()
            else:
                print('not found')
                digitalWrite(led_red_pin, 1)
                digitalWrite(led_green_pin, 0)
                messageDB = "Welcome," + plate_number +"\nVisitor " + datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                db.child("REC_001").push(messageDB, user['idToken'])
                setRGB(0, 255, 255)
                scroll_message(messageDB)
                time.sleep(2)
                empty_text()
                #closecam()
        else:
            print("\nNo Plate Number Detected")
            digitalWrite(led_green_pin, 0)
            digitalWrite(led_red_pin, 1)
            time.sleep(2)
            setText("Welcome to\nDallas Villa")
            empty_text()
            #closecam()
    except OSError as e:
        # Handle the exception
        print("Read vehicles number failed") 
def closecam(): 
    cap.release()
    cv2.destroyAllWindows()
    
def opengate():
    myServo.value = 1
    time.sleep(0.1)
  
    myServo.value = None
    time.sleep(1)
    
def closegate():
    myServo.value = -1
    time.sleep(0.1)
  
    myServo.value = None
    time.sleep(1)

#stop
def main():
    # Call your main function here
    digitalWrite(led_red_pin, 1)
    app.run(host='192.168.200.131', port=5000, debug=True, threaded=True)
    car_detection()
    
if __name__ == "__main__":
    main()
